package emailmanager;

import persitentobject.Persistent;
import persitentobject.PersistentObject;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import java.io.IOException;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class Email extends PersistentObject implements Persistent {

    private int id;
    private String body;
    private String sender;
    private String subject;
    private Date date;


    /**************************************************
     * Constructeur classique
     * @param id
     * @param sender
     * @param subject
     * @param body
     * @param date
     ****************************************************/
    public Email(int id, String sender, String subject, String body, Date date) {
        this.id = id;
        this.body = body;
        this.date = date;
        this.sender = sender;
        this.subject = subject;
    }

    /********************************************************
     * Autre constructeur qui se base sur un objet Message
     * @param message
     ********************************************************/
    public Email(Message message) {
        try {
            this.sender = ((Address) message.getFrom()[0]).toString();
            this.date = message.getSentDate();
            this.subject = message.getSubject();
            this.body = ReadEmails.getTextFromMessage(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /* GETTERS et SETTERS */

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    /* JDBC */

    /**************************************************************
     * Méthode servant à mettre à jours les données de la bdd par id
     * @return void
     **************************************************************/
    private void update() throws SQLException {
        String query = "UPDATE emails SET subject = ?, body = ?, sender = ?, date = ? WHERE id = ?";
        PreparedStatement st = dbConnection().prepareStatement(query);

        st.setString(1, getSubject());
        st.setString(2, getBody());
        st.setString(3, getSender());
        st.setTimestamp(4, new java.sql.Timestamp(getDate().getTime()));
        st.setInt(5, getId());

        st.executeUpdate();
    }

    /**************************************************************
     * Méthode servant à insérer un nouveau email
     * @return void
     **************************************************************/
    private void insert() throws SQLException {
        String query = "INSERT INTO emails(subject, body, sender, date) VALUES (?, ?, ?, ?)";
        PreparedStatement st = dbConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

        st.setString(1, getSubject());
        st.setString(2, getBody());
        st.setString(3, getSender());
        st.setTimestamp(4, new java.sql.Timestamp(getDate().getTime()));

        st.executeUpdate();

        ResultSet generatedKeys = st.getGeneratedKeys();
        generatedKeys.next();

        setId(generatedKeys.getInt(1));
    }

    /**************************************************************
     * Méthode à utiliser pour persister les données locales dans la bdd
     * @return void
     **************************************************************/
    @Override
    public void persist() throws SQLException {
        if (this.id < 1) {
            insert();
        }
        else {
            update();
        }
    }

    /**************************************************************
     * Méthode à utiliser pour populer l'instance en cours
     * @return void
     **************************************************************/
    @Override
    public void fetch() throws SQLException {
        PreparedStatement st = dbConnection().prepareStatement("SELECT * FROM emails WHERE id = ?");
        st.setInt(1, getId());

        ResultSet rs = st.executeQuery();
        rs.next();

        setSubject(rs.getString("subject"));
        setBody(rs.getString("body"));
        setSender(rs.getString("sender"));
        setDate(rs.getTimestamp("date"));

        st.close();
    }

    /**************************************************************
     * Méthode à utiliser pour retirer cette instance de la bdd
     * @return void
     **************************************************************/
    @Override
    public void delete() throws SQLException {

        String query = "DELETE FROM emails WHERE id = ?";
        PreparedStatement st = dbConnection().prepareStatement(query);

        st.setInt(1, getId());

        st.executeUpdate();
    }

    /**************************************************************
     * Méthode statique à utiliser pour récupérer une liste de Pays
     * @return une ArrayList de Pays
     **************************************************************/
    public static List<Email> fetchAll() throws SQLException {
        List<Email> emailList = new ArrayList<>();

            Statement st = dbConnection().createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM emails");

            while (rs.next()) {
                int id = rs.getInt("id");
                String sender = rs.getString("sender");
                String body = rs.getString("body");
                String subject = rs.getString("subject");
                Timestamp date = rs.getTimestamp("date");

                emailList.add(new Email(id, sender, subject, body, date));
            }

            st.close();

        return emailList;
    }

    /* OTHERS */

    @Override
    public String toString() {
        return subject;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Email email = (Email) o;
        return o.hashCode() == this.hashCode();
    }

    @Override
    public int hashCode() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String fDate = formatter.format(date);
        return Objects.hash(body, sender, subject, fDate);
    }

    public static void main(String[] args) {
        Email a = new Email(2, "a", "a", "a", new Date());
        Email z = new Email(2, "a", "a", "a", new Timestamp(new Date().getTime()));
        Email e = new Email(2, "z", "a", "a", new Timestamp(new Date().getTime()));

        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");

        List<Email> r = new ArrayList<>();
        r.add(a);

        System.out.println(r.contains(z));
        System.out.println(r.contains(e));
        System.out.println(a.getDate());
        System.out.println(e.getDate());
        System.out.println(formatter.format(a.getDate()));
        System.out.println(formatter.format(e.getDate()));
    }
}
