package emailmanager;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class EmailManager
{
    private final String username = "ynovsd@gmail.com" ; // votre compte gmail
    private final String password = "spkhiggetswqrtyx" ; // le mot de passe d'application que google vous a donné
    private Properties prop ;
    private Session session ;

    public EmailManager()
    {
        // on peut remonter au niveau du constructeur l'initialisation des propriétés du serveur mail
        prop = new Properties() ;
        // propriétés du serveur SMTP
        prop.put("mail.smtp.host", "smtp.gmail.com") ;
        prop.put("mail.smtp.port", "587") ;
        prop.put("mail.smtp.auth", "true") ;
        prop.put("mail.smtp.starttls.enable", "true") ;
        // propriétés du serveur IMAP
        prop.put("mail.imap.host", "imap.gmail.com") ;
        prop.put("mail.imap.port", "993") ;
        prop.put("mail.imap.starttls.enable", "true") ;

        // création de la session
        session = Session.getInstance(prop,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });
    }

    /**********************************************************************
     * Envoi d'un email
     * @param destinataire
     * @param sujet
     * @param message
     **********************************************************************/
    public void sendEmail(String destinataire, String sujet, String message)
    {
        try
        {
            // on créé l'email qu'on va envoyer
            Message email = new MimeMessage(session);
            // on lui donne les bonnes valeurs
            email.setRecipient(MimeMessage.RecipientType.TO,
                    new InternetAddress(destinataire));
            email.setSubject(sujet);
            email.setText(message);

            // on envoie l'email
            Transport.send(email);
        }
        catch (MessagingException e)
        {
            e.printStackTrace();
        }
    }

    /***************************************************************************
     * Récupération des emails reçus sous forme de liste
     * @return emails reçus
     ***************************************************************************/
    public List<Email> readEmails()
    {
        List<Email> results = new ArrayList<>() ;
        try
        {
            Store store = session.getStore("imaps") ;
            store.connect("imap.gmail.com", username, password);

            Folder emailFolder = store.getFolder("INBOX") ;
            emailFolder.open(Folder.READ_ONLY);
            for (Message message : emailFolder.getMessages())
            {
                // on construit un objet de type Email d'après le Message
                Email email = new Email(message) ;
                // on l'ajoute à la liste de résultats
                results.add(email) ;
            }
            // on ferme le dossier et le store
            emailFolder.close();
            store.close();
            // et on renvoie la liste créée
            return results ;
        }
        catch (MessagingException e)
        {
            e.printStackTrace();
            return results ;
        }
    }

    public static void main(String[] args) {
        EmailManager myManager = new EmailManager() ;

        /* TEST ENVOI D'EMAIL */
        //myManager.sendEmail("tristandu06@gmail.com", "email de test", "ceci est un message envoyé depuis java");

        /* TEST DE RECEPTION D'EMAIL */
        for (Email email : myManager.readEmails())
        {
            System.out.println(email); // on fait appel au toString() de Email
        }

    }
}
