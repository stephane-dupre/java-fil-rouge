package com.example.demo;

import emailmanager.Email;
import emailmanager.EmailManager;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;


public class HelloController {
    private List<Email> emailList;
    private ChangeListener listener;

    @FXML
    private TreeView tree;

    @FXML
    private WebView web;

    @FXML
    private MenuItem refresh;

    @FXML
    private Label status;

    @FXML
    public void refreshAction() {
        status.setText("Récupération des emails depuis la boîte mail");

        // On crée un nouveau thread pour empêcher l'app de freeze pendant le fetch de la boîte mail
        // Vu que l'on start le Runner immédiatement, on le passe en callback dans le constructeur
        new Thread(() -> {
            EmailManager emailManager = new EmailManager();
            List<Email> emails = emailManager.readEmails();

            for (Email email : emails)  {
                // On ne persiste pas si les emails sont déjà présent en local
                if (emailList.contains(email)) continue;
                try {
                    email.persist();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            tree.getSelectionModel().selectedItemProperty().removeListener(listener);

            // JavaFX est singlethreaded
            // On utilise Platform.runLater pour mettre la GUI à jour depuis notre nouveau thread
            Platform.runLater(() -> initialize());
        }).start();
    }

    /**
     * Affiche la fenêtre d'envoi d'un email
     * @throws IOException
     */
    @FXML
    public void sendAction() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("send-view.fxml"));
        Parent root = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Envoyer un email");
        stage.setScene(new Scene(root));
        stage.show();
    }

    /**
     * Affiche la modale à propos
     */
    @FXML
    public void aboutAction() {
        Image image = new Image("https://hub.ynov.com/medias/group/4885004055cd155d99144d.png");
        ImageView imageView = new ImageView(image);

        ButtonType close = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);

        Dialog<String> dialog = new Dialog<>();
        dialog.setHeight(300);
        dialog.setWidth(600);
        dialog.setGraphic(imageView);
        dialog.getDialogPane().getButtonTypes().add(close);
        dialog.setTitle("A propos");
        dialog.setContentText("Ce logiciel est un client email simple permettant de récupérer les emails reçus sur un adresse Gmail. Il est réalisé dans le cadre du cours \"Développement Desktop\" pour les B3 de Ynov Sophia");

        dialog.showAndWait();
    }

    /**
     * Initialise l'application
     */
    public void initialize() {
        status.setText("Récupération des emails depuis la base de donnée");
        try {
            List<Email> emails = Email.fetchAll();

            setEmailList(emails);

            TreeItem<Object> root = new TreeItem<>("Boite de reception");
            for (Email email : emailList) {
                try {
                    root.getChildren().add(new TreeItem<>(email));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            tree.setRoot(root);
            root.setExpanded(true);

            listener = new ChangeListener() {
                @Override
                public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                    TreeItem<Email> selectedItem = (TreeItem<Email>) newValue;
                    if (selectedItem.getValue() instanceof Email) {
                        Email selectedEmail = (Email) selectedItem.getValue();
                        WebEngine webEngine = web.getEngine();
                        String webContent = "Expediteur : " + selectedEmail.getSender() + "<br>"
                                + selectedEmail.getBody();
                        webEngine.loadContent(webContent);
                    }
                }
            };
            SelectionModel sm = tree.getSelectionModel();
            sm.selectedItemProperty().addListener(listener);
            status.setText("Dernière mise à jour : " + new Date());
        } catch (SQLException e) {
            e.printStackTrace();
            status.setText("Erreur");
        }
    }

    /* GETTERS & SETTERS */

    public List<Email> getEmailList() {
        return emailList;
    }

    public void setEmailList(List<Email> emailList) {
        this.emailList = emailList;
    }
}
