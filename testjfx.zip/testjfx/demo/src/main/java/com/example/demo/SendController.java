package com.example.demo;

import emailmanager.EmailManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SendController {
    @FXML
    private TextField recipient;

    @FXML
    private TextField subject;

    @FXML
    private TextArea body;

    @FXML
    private Button btn;

    /***************************************************************************
     * Envoie un email au destinataire et ferme la fenêtre d'envoi d'email
     ***************************************************************************/
    @FXML
    public void send() {
        try {
            String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
            if(!recipient.getText().matches(regex)) return;
            EmailManager emailManager = new EmailManager();
            emailManager.sendEmail(recipient.getText(), subject.getText(), body.getText());
            Stage stage = (Stage) btn.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
