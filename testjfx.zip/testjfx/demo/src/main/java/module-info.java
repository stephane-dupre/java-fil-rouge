module com.example.demo {
    requires javafx.fxml;
    requires javafx.web;
    requires java.mail;
    requires org.jsoup;
    requires java.sql;


    opens com.example.demo to javafx.fxml;
    exports com.example.demo;
    exports emailmanager;
    opens emailmanager to javafx.fxml;
}