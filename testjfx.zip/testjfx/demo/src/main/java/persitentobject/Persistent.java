package persitentobject;

import java.sql.SQLException;

public interface Persistent {
    void delete() throws SQLException;
    void persist() throws SQLException;
    void fetch() throws SQLException;
}
