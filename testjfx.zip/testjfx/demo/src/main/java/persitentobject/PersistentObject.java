package persitentobject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public abstract class PersistentObject implements Persistent {
    public static final String HOST = "localhost";
    public static final String PORT = "3306";
    public static final String DATABASE_NAME = "testjdbc";
    public static final String USER = "root";
    public static final String PASSWORD = "root";
    public static final String DATABASE_URL = "jdbc:mysql://"+HOST+":"+PORT+"/"+DATABASE_NAME;

    /**************************************************************
     * Cette méthode doit persister les données
     * @return void
     **************************************************************/
    public abstract void persist() throws SQLException;

    /**************************************************************
     * Cette méthode doit éffacer les données de l'instance de la bdd
     * @return void
     **************************************************************/
    public abstract void delete() throws SQLException;

    /**************************************************************
     * Cette méthode doit populer les données de la bdd dans l'instance
     * @return void
     **************************************************************/
    public abstract void fetch() throws SQLException;

    /**************************************************************
     * Cette methode n'existe que pour être réécrite.
     * Elle doit retourner une List d'instance de classe heritant de PersitentObject
     * @return void
     **************************************************************/
    public static List<? extends PersistentObject> fetchAll() throws SQLException {
        return new ArrayList<>();
    };

    /**************************************************************
     * Methode statique utilisée pour établir une connection avec la bdd
     * La configuration se fait directement dans la Classe PersistentObject
     * @return Connection
     **************************************************************/
    public static Connection dbConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
    }
}
